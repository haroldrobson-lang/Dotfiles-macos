return {
  -- 1. Primary Java Development Environment
  {
    "nvim-java/nvim-java",
    ft = { "java" },
    dependencies = {
      "nvim-java/lua-async-await",
      "nvim-java/nvim-java-core",
      "nvim-java/nvim-java-test",
      "nvim-java/nvim-java-dap",
      "MunifTanjim/nui.nvim",
      "mfussenegger/nvim-dap",
      {
        "williamboman/mason.nvim",
        opts = {
          registries = {
            "github:nvim-java/mason-registry",
            "github:mason-org/mason-registry",
          },
        },
      },
    },
    config = function()
      -- Must be called before setting up lspconfig jdtls
      require("java").setup({
        spring_boot_tools = { enable = true },
        jdk = { auto_install = false },
      })

      require("lspconfig").jdtls.setup({
        settings = {
          java = {
            configuration = {
              runtimes = {
                {
                  name = "JavaSE-21",
                  path = vim.fn.expand("~/.sdkman/candidates/java/current"),
                  default = true,
                },
              },
            },
          },
        },
      })
    end,
  },

  -- 2. Prevent LazyVim Override & Configure Companion LSPs
  {
    "neovim/nvim-lspconfig",
    opts = {
      servers = {
        lemminx = {},
        yamlls = {
          settings = {
            yaml = {
              schemas = {
                ["https://json.schemastore.org/springboot-application.json"] = "application*.yml",
              },
            },
          },
        },
      },
      setup = {
        jdtls = function()
          -- Returning true tells LazyVim NOT to run its own lspconfig setup for JDTLS
          return true
        end,
      },
    },
  },

  -- 3. Formatter (Delegated to LazyVim auto-formatting)
  {
    "stevearc/conform.nvim",
    opts = {
      formatters_by_ft = {
        java = { "google-java-format" },
      },
    },
  },

  -- 4. Debugger UI
  {
    "rcarriga/nvim-dap-ui",
    dependencies = { "mfussenegger/nvim-dap", "nvim-neotest/nvim-nio" },
    config = function()
      local dap, dapui = require("dap"), require("dapui")
      dapui.setup()
      dap.listeners.after.event_initialized["dapui_config"] = function()
        dapui.open()
      end
      dap.listeners.before.event_terminated["dapui_config"] = function()
        dapui.close()
      end
      dap.listeners.before.event_exited["dapui_config"] = function()
        dapui.close()
      end
    end,
  },

  -- 5. Treesitter Syntax Highlighting
  {
    "nvim-treesitter/nvim-treesitter",
    opts = function(_, opts)
      if type(opts.ensure_installed) == "table" then
        vim.list_extend(opts.ensure_installed, { "java", "xml", "yaml", "properties" })
      end
    end,
  },
}
